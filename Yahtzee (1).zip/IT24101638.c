#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
// Defining the colours
#define RED "\033[31m"
#define RESET "\033[0m"
#define BLUE "\033[34m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"

// Function for finding 1s,2s,3s,4s,5s and 6s
int findNs(const char *pvals, int n) {
	int count=0,i;
	for (i = 0 ; i < 5 ; i++){
		if(pvals[i]==n){
			count++;
		}
	}
	return count*n;
}
// Function for finding three of a kind
int findThreeKind(const char *pvals) {
	int i,f,sum=0;
	char a[5];
	for (i = 0 ; i < 5 ; i++) {
		a[i]=pvals[i];
		sum+=pvals[i];
	}
	
	int count1=0 , count2=0 , count3=0 , count4=0 , count5=0 , count6=0;
	for (i = 0 ; i < 5 ; i++){
		if(a[i]==1)
			count1+=1;
		else if(a[i]==2)
			count2+=1;
		else if(a[i]==3)
			count3+=1;
		else if(a[i]==4)
			count4+=1;
		else if(a[i]==5)
			count5+=1;
		else if(a[i]==6)
			count6+=1;
	}
	int k[]={count1,count2,count3,count4,count5,count6};
	for (f=0;f<6;f++){
		if(k[f]>=3){
			return sum;
		}
	}
	return 0;
}
// Function for finding Four of a Kind
int findFourKind(const char *pvals) {
	int i,sum=0;
	char a[5];
	for (i = 0 ; i < 5 ; i++) {
		a[i]=pvals[i];
		sum+=pvals[i];
	}
	int count1=0 , count2=0 , count3=0 , count4=0 , count5=0 , count6=0;
	for (i=0;i<5;i++){
		if(a[i]==1)
			count1+=1;
		else if(a[i]==2)
			count2+=1;
		else if(a[i]==3)
			count3+=1;
		else if(a[i]==4)
			count4+=1;
		else if(a[i]==5)
			count5+=1;
		else if(a[i]==6)
			count6+=1;
	}
	int k[]={count1,count2,count3,count4,count5,count6};
	for (i=0;i<6;i++){
		if(k[i]>=4){
			return sum;
		}
	}
	return 0;
}
// Function for finding Full House
int findFullHouse(const char *pvals) {
	int i, val;
	int count[6]; 
	
	for (i = 0; i < 6; i++)
		count[i] = 0;
	for (i = 0; i < 5; i++){
		val = pvals[i];
		count[val-1]++;
	}
	bool c3 = false;
	bool c2 = false;
	
	for (i = 0; i < 6; i++){
		if (count[i] == 3)
			c3 = true;	
		else if (count[i] == 2)
			c2 = true;
	}

	if (c3 && c2)
		return 25;
	else
		return 0;
}
// Function for finding Small Straight
int findSmallStrt(const char *pvals) {
	int i,n,a[5];
	int temp,count=0,point=0;
	for (i = 0 ; i < 5 ; i++){
		a[i]=pvals[i];
	}
	for (i=0; i<5; i++){
		for(n=0;n<4;n++){
			if (a[n] > a[n+1]){
				temp=a[n];
				a[n]=a[n+1];
				a[n+1]=temp;
			}
		}
	}
	for (i = 0 ; i < 4 ; i++){
		if(a[i]+1==a[i+1]){
			count++;
			point=1;
		}
		else if(a[i]==a[i+1]){
			continue;
		}
		else if(point==0){ //&& count > 0){
			if(count>0 && !(count>=3))count--;
			continue;
		}
		point=0;
	}
	if(count>=3){
		return 30;
	}
	return 0;
}
// Function for finding Large Straight
int findLargeStrt(const char *pvals) {
	int i,n,a[5];
	int temp,count=0;
	for (i = 0 ; i < 5 ; i++){
		a[i]=pvals[i];
	}
	for (i=0; i<5; i++){
		for(n=0;n<4;n++){
			if (a[n] > a[n+1]){
				temp=a[n];
				a[n]=a[n+1];
				a[n+1]=temp;
			}
		}
	}
	for (i = 0 ; i < 4 ; i++){
		if(a[i]+1==a[i+1]){
			count++;
		}
	}
	if(count==4){
		return 40;
	}	
	return 0;
}
// Function for finding Yahtzee
int findYahtzee(const char *pvals) {
	int i,a[5],count=0;
	for (i = 0 ; i < 5 ; i++){
		a[i]=pvals[i];
	}
	for (i = 0 ; i < 4 ; i++){
		if(a[i]==a[i+1]){
			count++;
		}
	}
	if(count==4){
		return 50;
	}
	return 0;
}
// Function for finding Chance
int findChance(const char *pvals) {
	int sum = 0,i;
	for (i = 0 ; i < 5 ; i++){
		sum+=pvals[i];
	}
	return sum;
}
// =====================================================================================================================================
int Round(bool human, char *pUsedCats,int finals){
	
	// declare variables
	char catNames[13][50] = {"Once", "Twos", "Threes", "Fours", "Fives", "Sixes", "Three of a kind", "Four of a kind", "Full house",
		"Small straight", "Large straight", "Yahtzee", "Chance"};

	char scores[13];
	char values[5];
	//char values[5] ={6,6,6,6,6};

	char catmaxmarks[13]={5,10,15,20,25,30,30,30,25,30,40,50,30};
	
	bool keep[5];
	int i = 0;
	int choice_count = 0;
	
	// init arrays
	for (i = 0; i < 5; i++) {
		values[i] = 0;
		keep[i] = false;
	}
	srand(time(0));
	
	while (choice_count<3) {

		// roll dices
		
		for (i =0; i < 5; i++) {
			if (keep[i] == false) {
				values[i] = (rand() % 6)+1;
			}	
		}
		
		// show dices
		printf("\nDices Number :'1'  '2'  '3'  '4'  '5' \n");
		printf("Values       :");
	
		for (i = 0 ; i < 5; i++){
			if(keep[i]==false){
				if (i == 4)
					printf(" %d\n",values[i]);
				else
					printf(" %d   ",values[i]);
			}
			else{
				if (i == 4)
					printf(YELLOW" [%d]\n"RESET,values[i]);
				else
					printf(YELLOW" [%d]   "RESET,values[i]);
			}
		}	
		
		printf("\n");
		int j=0;
					
		// find scores for catagories				
		for (i = 0; i < 13; i++) {
			if (pUsedCats[i] == 1)
				scores[i] = 0;
			else {
				switch (i) {  
			
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
					scores[i] = findNs(values, i+1);
					break;
				case 6:
					scores[i] = findThreeKind(values);
					break;
				case 7:
					scores[i] = findFourKind(values);
					break;
				case 8:
					scores[i] = findFullHouse(values);
					break;
				case 9:
					scores[i] = findSmallStrt(values);
					break;
				case 10:
					scores[i] = findLargeStrt(values);
					break;
				case 11:
					scores[i] = findYahtzee(values);
					break;
				case 12:
					scores[i] = findChance(values);
					break;
				}
			}
		}
	
		// show score catagories
		for (i = 0; i < 13; i++) {
			if(pUsedCats[i]==1){
				printf(YELLOW"'%d' %s : %d #Used#\n"RESET, i+1, catNames[i], scores[i]);
				continue;
			}
			printf("'%d' %s : %d\n", i+1, catNames[i], scores[i]);
		}

		// Human Part
		if (human) {
			int q,l;
			if (choice_count==2){
				while(true){
					printf("\n\nEnter 1-13 to choose a catagory: ");
					scanf("%d",&q);
					if (q<=13 && q>0 && pUsedCats[q-1]==0)
						break;
					if (q>13 || q<=0){printf("Invalid Number!!\n");}
					else{printf("Invalid Number!!\nPreviously used catogory!!\n");}
				}
				pUsedCats[q-1] = 1;
				return scores[q-1];
			}
			do{
				printf("\n\nEnter 0 to roll again or enter 1-13 to choose a catagory: ");
				scanf("%d",&q);
				if (pUsedCats[q-1]==1){
					printf("Invalid Number!!\n");
					printf("Previously used catogory!!\n");
				}
				else if (q<0 || q>13)
					printf("Invalid Number!!\n");
			}while((q<0 || q>13) || pUsedCats[q-1]==1);
			
			if (q==0){
				for (i = 0; i < 5; i++){
					printf("\nEnter the dice numbers that you need to keep,\n");
					printf("or enter the number of the dice that needs to be released.\n");
					printf("Or enter 0 if you are done choosing or no dices are going to be choosen: ");
					scanf("%d",&l);
					if (l>6 || l<0){
						printf("Invalid Number!!\n");
						i--;
						continue;	
					}
					else if (l==0){
						break;
					}
					else if(keep[l-1]==true){
						keep[l-1]=false;
						i--;
						continue;
					}
					keep[l-1]=true;
				}
			}	
			else{
				pUsedCats[q-1] = 1;
				return scores[q-1];
			}
		}
		//Computer AI	
		else {
			int n;
			char a[13],temp,last=0,count=0,_0count=0;
			sleep(1);
			for (i = 0; i < 13; i++){
				a[i]=scores[i];
			}
			for (i=0; i<13; i++){
				for(n=0;n<12;n++){
					if (a[n] > a[n+1]){
						temp=a[n];
						a[n]=a[n+1];
						a[n+1]=temp;
					}
				}
			}
			for (i = 0; i < 13; i++){
				if (last==0) last = (a[12]==scores[i]) ? i : 0;
				if(a[i]==0) _0count++;
			}
			for (i = 12; i >= 0; i--){
				if(catmaxmarks[i]==scores[i]){
					pUsedCats[i]=1;
					printf("					COMPUTER used %s\n",catNames[i]);
					return scores[i];
				}
			}
			for (i = 12; i >= 0; i--){
				if(scores[i]>=(float)catmaxmarks[i]*3/4){
					pUsedCats[i]=1;
					printf("					COMPUTER used %s\n",catNames[i]);
					return scores[i];
				}
				else if(choice_count<2 && _0count!=13 && finals==9){
					pUsedCats[last]=1;
					printf("					COMPUTER used %s\n",catNames[last]);
					return scores[last];
				}
			}
			if(_0count==13 && choice_count==2){
				for(i=12;i>=0;i--){
					if(scores[i]==0 && pUsedCats[i]==0){
						pUsedCats[i]=1;
						printf("					COMPUTER used %s\n",catNames[i]);
						return scores[i];
					}
				}
			}
				
			if(choice_count!=2){
				for (i = 0; i < 5; i++){
					if (values[i] > 3){
						keep[i]=true;
						count++;
						sleep(1);
						printf("\nKeeping Dices %d...\n",i+1);
					}
				}
				if(count==0){choice_count++;continue;}
			}
			else{
				pUsedCats[last]=1;
				printf("					COMPUTER used %s\n",catNames[last]);
				return scores[last];
			}
		}
		//Incrimentation of the choice
		choice_count++;	
	}
}

// ============================================================================
int main(){
	char name[50];
	
	printf("|===================================================|\n");
	printf("|  __   __         _       _                        |\n");
	printf("|  \\ \\ / /  __ _  | |__   | |_   ____   ___    ___  |\n");
	printf("|   \\ V /  / _` | | '_ \\  | __| |_  /  / _ \\  / _ \\ |\n");
	printf("|    | |  | (_| | | | | | | |_   / /  |  __/ |  __/ |\n");
	printf("|    |_|   \\__,_| |_| |_|  \\__| /___|  \\___|  \\___  |\n");
	printf("|===================================================|\n");
    printf(BLUE"|>>>>>>>>>>>>>>>>>By Thenul Ranmuthu<<<<<<<<<<<<<<<<|\n"RESET);
    
	printf("\nEnter your name to start the game : ");
	
	scanf("%s",name);
	
	int ready;
	
	printf("\nHello %s!!\n\nEnter '1' when you are ready to start : ",name);
	
	scanf("%d", &ready);
	
	if (ready!=1)
		return 0;
	
	int hScore = 0, cScore = 0;
	int i = 0;
	char usedHCats[13], usedCCats[13]; 
	// initialize userCats[]s
	for (i = 0; i < 13; i++){
		usedHCats[i]=0;
		usedCCats[i]=0;
	}
	int finals=0;
	// Go through 13 rounds
	for (i = 0; i < 13; i++) {
		if(i==9) finals=i;
		hScore += Round(true, usedHCats,finals);
		printf("                                                                              %s's total = %d\n\n\n",name,hScore);
		printf("                                                                              COMPUTER's total = %d\n\n",cScore);
		printf(RED"                                                          (\\_/)\n"RESET);
		printf(RED"                                             The COMPUTER ('8')\n"RESET);
		printf(RED"                                                          />O<\\ \n\n"RESET);
		cScore += Round(false, usedCCats,finals);	
		printf("                                                                              COMPUTER's total = %d\n\n",cScore);
		printf("                                                                              %s's total = %d\n\n\n",name,hScore);
	}
	if (hScore>cScore){
		//Declearing the player's victory
		printf(GREEN"\n\n\n %s WON THE GAME!!!!!!  \n\n\n"RESET,name);
		printf(BLUE"__     ___      _                     _ _\n"RESET);
		printf(BLUE"\\ \\   / (_) ___| |_ ___  _ __ _   _  | | |\n"RESET);
    	printf(BLUE" \\ \\ / /| |/ __| __/ _ \\| '__| | | | | | |\n"RESET);
    	printf(BLUE"  \\ V / | | (__| || (_) | |  | |_| | |_|_|\n"RESET);
    	printf(BLUE"   \\_/  |_|\\___|\\__\\___/|_|   \\__, | (_|_)\n"RESET);
    	printf(BLUE"              		      |___/\n"RESET);
	}
	else if(hScore==cScore){
		//In case of a tied game
		printf("\n\n\n     MATCH TIED!!       \n\n\n");
	}
	//Presenting the computer's victory
	else{
		printf(RED"\n\n\n COMPUTER WON THE GAME!!!!!\n\n\n"RESET);
		printf(RED"             (\\_/)\n"RESET);
		printf(RED"             ('8')\n"RESET);
		printf(RED"             />O<\\ \n\n"RESET);
	}
	return 0;
}
