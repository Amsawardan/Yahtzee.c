#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

#define NUM_DICE 5
#define NUM_ROLLS 3
#define NUM_ROUNDS 13
#define NUM_CATEGORIES 13

// Function prototypes
void rollDice(int dice[], int keep[]);
void displayDice(const int dice[]);
void resetKeepArray(int keep[]);
int calculateScore(int dice[], int category);
void playerTurn(int dice[], int keep[]);
void computerTurn(int dice[], int keep[], int categoriesUsed[]);
int chooseCategory(int categoriesUsed[]);
int bestCategory(int dice[], int categoriesUsed[]);
bool isCategoryUsed(int category, int categoriesUsed[]);
void displayScores(int humanScore, int computerScore);
void displayFinalScores(int humanScore, int computerScore);
void play();
void displayTurnInfo(int round, int player);
int SmallValueSection(int dice[], int targetValue);
bool ThreeOfAKind(int dice[]);
bool FourOfAKind(int dice[]);
bool FullHouse(int dice[]);
bool SmallStraight(int dice[]);
bool LargeStraight(int dice[]);
bool Yahtzee(int dice[]);
int sumOfDice(int dice[]);
void playYahtzee();

// Global variables for the game
int humanScore = 0, computerScore = 0;
int humanCategoriesUsed[NUM_CATEGORIES] = {0};
int computerCategoriesUsed[NUM_CATEGORIES] = {0};
char playerName[50];
int categoriesUsed[NUM_CATEGORIES] = {0};
int dice[NUM_DICE];

// Function to print rules
void printRules() {
    printf("\nHello %s, Here are the Yahtzee game rules:\n", playerName);
    printf("1. You will roll five dice and choose a category to score each turn.\n");
    printf("2. There are 13 categories, each with different scoring rules.\n");
    printf("3. Categories include: Ones, Twos, Threes, Fours, Fives, Sixes, Three of a Kind, Four of a Kind, Full House, Small Straight, Large Straight, Yahtzee, and Chance.\n");
    printf("4. Each category can be used only once.\n");
    printf("5. The goal is to get the highest possible score by the end of the game.\n");
    printf("\nGood luck and enjoy playing Yahtzee!\n");

    // Asking the player to agree to the rules
    char response;
    printf("Do you agree to the rules? (y/n): ");
    scanf(" %c", &response);

    if (response != 'y' && response != 'Y') {
        printf("Ending the game. Goodbye!\n");
        exit(0);  // Exit the game
    }
}

// Main function
int main() {
    // Seed random number generator
    srand(time(NULL));
    
    printf("\n\n*====================\n");
    printf("-----------Welcome to Yahtzee!-----------\n");
    printf("====================*\n");
    
    // Get player name
    printf("Enter your name: ");
    fgets(playerName, 50, stdin);
    playerName[strcspn(playerName, "\n")] = 0;  // Remove trailing newline
    
    // Show rules
    printRules();
    
    // Start the game
    play();
    
    return 0;
}

// Function to display the main menu
void play() {
    printf("\nStarting the game...\n");
    // You can add the game loop here
    // Example: The game continues until all categories are filled
    playYahtzee();
}

// Function to start the game
void playYahtzee() {
    // Initialize scores and category usage tracking
    humanScore = 0;
    computerScore = 0;
    for (int i = 0; i < NUM_CATEGORIES; i++) {
        humanCategoriesUsed[i] = 0;
        computerCategoriesUsed[i] = 0;
    }
    
    int dice[NUM_DICE];
    int keep[NUM_DICE] = {1, 1, 1, 1, 1};  // Track which dice to keep
    
    // Play 13 rounds
    for (int round = 1; round <= NUM_ROUNDS; round++) {
        printf("\n--- ( Round %d ) ---\n", round);
        
        // Player's turn
        displayTurnInfo(round, 1);  // 1 for player
        playerTurn(dice, keep);     // Call the updated function
        int playerCategory = chooseCategory(humanCategoriesUsed);
        humanScore += calculateScore(dice, playerCategory);
        
        // Computer's turn
        displayTurnInfo(round, 2);  // 2 for computer
        computerTurn(dice, keep, computerCategoriesUsed);
        int computerCategory = bestCategory(dice, computerCategoriesUsed);
        computerScore += calculateScore(dice, computerCategory);
        
        // Display scores after each round
        displayScores(humanScore, computerScore);
    }
    
    // Display final scores and winner
    displayFinalScores(humanScore, computerScore);
}

// Function to roll dice
void rollDice(int dice[], int keep[]) {
    for (int i = 0; i < NUM_DICE; i++) {
        if (!keep[i]) {
            dice[i] = (rand() % 6) + 1;  // Roll a new number if the dice is not kept
        }
    }
}

// Function to display the current dice values
void displayDice(const int dice[]) {
    printf("Dice: ");
    for (int i = 0; i < NUM_DICE; i++) {
        printf("%d ", dice[i]);
    }
    printf("\n");
}

// Function to reset the keep array (all dice will be re-rolled)
void resetKeepArray(int keep[]) {
    for (int i = 0; i < NUM_DICE; i++) {
        keep[i] = 0;
    }
}

// Function to display the turn info
void displayTurnInfo(int round, int player) {
    if (player == 1) {
        printf("\n%s's turn - Round %d\n", playerName, round);  // Display player's name
    } else {
        printf("\nComputer's turn - Round %d\n", round);
    }
}


// Function to calculate score based on category
int calculateScore(int dice[], int category) {
    int score = 0;
    switch (category) {
        case 1: score = SmallValueSection(dice, 1); break;  // Ones
        case 2: score = SmallValueSection(dice, 2); break;  // Twos
        case 3: score = SmallValueSection(dice, 3); break;  // Threes
        case 4: score = SmallValueSection(dice, 4); break;  // Fours
        case 5: score = SmallValueSection(dice, 5); break;  // Fives
        case 6: score = SmallValueSection(dice, 6); break;  // Sixes
        case 7: score = ThreeOfAKind(dice) ? sumOfDice(dice) : 0; break;
        case 8: score = FourOfAKind(dice) ? sumOfDice(dice) : 0; break;
        case 9: score = FullHouse(dice) ? 25 : 0; break;
        case 10: score = SmallStraight(dice) ? 30 : 0; break;
        case 11: score = LargeStraight(dice) ? 40 : 0; break;
        case 12: score = Yahtzee(dice) ? 50 : 0; break;
        case 13: score = sumOfDice(dice); break;  // Chance
        default: score = 0; break;
    }
    return score;
}

// Function to calculate score for upper section (Ones, Twos, etc.)
int SmallValueSection(int dice[], int targetValue) {
    int score = 0;
    for (int i = 0; i < NUM_DICE; i++) {
        if (dice[i] == targetValue) {
            score += targetValue;
        }
    }
    return score;
}

// Function to simulate player's turn (formerly aliceTurn)
void playerTurn(int dice[], int keep[]) {
    resetKeepArray(keep);  // Reset keep array at the start of each turn
    int reroll;
    
    for (int i = 0; i < NUM_ROLLS; i++) {
        rollDice(dice, keep);
        displayDice(dice);

        printf("Do you want to Reroll(1-yes/0-no): ");
        scanf("%d", &reroll);

        if (reroll == 0)
            break;
        
        if (i < NUM_ROLLS - 1) {
            printf("Enter 1 to keep the dice, 0 to re-roll:\n");
            for (int j = 0; j < NUM_DICE; j++) {
                printf("Keep dice %d? ", j + 1);
                scanf("%d", &keep[j]);  
            }
        }
    }
}

// Function to simulate computer's turn
void computerTurn(int dice[], int keep[], int categoriesUsed[]) {
    resetKeepArray(keep);  // Reset keep array at the start of each turn

    // First Roll
    rollDice(dice, keep);
    displayDice(dice);

    // Computer decides which dice to keep based on current roll
    for (int i = 0; i < NUM_ROLLS - 1; i++) {
        if (Yahtzee(dice)) {
            for (int j = 0; j < NUM_DICE; j++) {
                keep[j] = 1;  // Keep all dice if Yahtzee
            }
            printf("Computer has Yahtzee! Keeping all dice.\n");
            break;
        } else if (FullHouse(dice)) {
            for (int j = 0; j < NUM_DICE; j++) {
                keep[j] = 1;  // Keep all dice for Full House
            }
            printf("Computer has Full House! Keeping all dice.\n");
            break;
        } else if (LargeStraight(dice)) {
            for (int j = 0; j < NUM_DICE; j++) {
                keep[j] = 1;  // Keep all dice for Large Straight
            }
            printf("Computer has Large Straight! Keeping all dice.\n");
            break;
        } else if (SmallStraight(dice)) {
            for (int j = 0; j < NUM_DICE; j++) {
                keep[j] = 1;  // Keep all dice for Small Straight
            }
            printf("Computer has Small Straight! Keeping all dice.\n");
            break;
        } else {
            // Determine the best scoring option for Ones, Twos, Threes, etc.
            int targetValue = -1;
            int maxScore = -1;

            // Look for the best available category (Ones, Twos, etc.) and calculate potential scores
            for (int value = 1; value <= 6; value++) {
                if (!isCategoryUsed(value, categoriesUsed)) {
                    int score = SmallValueSection(dice, value);
                    if (score > maxScore) {
                        maxScore = score;
                        targetValue = value;
                    }
                }
            }

            // Now we know the best target value (Ones, Twos, etc.)
            for (int j = 0; j < NUM_DICE; j++) {
                if (dice[j] == targetValue) {
                    keep[j] = 1;  // Keep dice that match the best target value
                } else {
                    keep[j] = 0;  // Reroll others
                }
            }
            printf("Computer is keeping dice that match the best category (e.g., %ds).\n", targetValue);
        }

        // Re-roll dice based on AI decision to keep or reroll
        rollDice(dice, keep);
        displayDice(dice);
    }

    // After the third roll, select the best available category
    int computerCategory = bestCategory(dice, categoriesUsed);
    printf("Computer chooses category %d\n", computerCategory);
}

// Function to check if a category has been used
bool isCategoryUsed(int category, int categoriesUsed[]) {
    return categoriesUsed[category - 1];  // Adjust for 0-based index
}

// Function to display scores
void displayScores(int humanScore, int computerScore) {
    printf("Scores - Human: %d | Computer: %d\n", humanScore, computerScore);
}

// Function to display final scores and winner
void displayFinalScores(int humanScore, int computerScore) {
    printf("\nFinal Scores - Human: %d | Computer: %d\n", humanScore, computerScore);
    if (humanScore > computerScore) {
        printf("Congratulations! You win!\n");
    } else if (computerScore > humanScore) {
        printf("Computer wins!\n");
    } else {
        printf("It's a tie!\n");
    }
}

// Other functions for the game (Three of a Kind, Four of a Kind, etc.) 

// Example implementation for checking combinations
bool ThreeOfAKind(int dice[]) {
    int counts[7] = {0};  // Index 0 will be unused
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    for (int i = 1; i <= 6; i++) {
        if (counts[i] >= 3) {
            return true;
        }
    }
    return false;
}

bool FourOfAKind(int dice[]) {
    int counts[7] = {0};
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    for (int i = 1; i <= 6; i++) {
        if (counts[i] >= 4) {
            return true;
        }
    }
    return false;
}

bool FullHouse(int dice[]) {
    int counts[7] = {0};
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    bool hasThree = false, hasTwo = false;
    for (int i = 1; i <= 6; i++) {
        if (counts[i] == 3) {
            hasThree = true;
        } else if (counts[i] == 2) {
            hasTwo = true;
        }
    }
    return hasThree && hasTwo;
}

bool SmallStraight(int dice[]) {
    int counts[7] = {0};
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    return (counts[1] && counts[2] && counts[3] && counts[4]) ||
           (counts[2] && counts[3] && counts[4] && counts[5]) ||
           (counts[3] && counts[4] && counts[5] && counts[6]);
}

bool LargeStraight(int dice[]) {
    int counts[7] = {0};
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    if (counts[1] && counts[2] && counts[3] && counts[4] && counts[5]) {
        return true;
    }
    if (counts[2] && counts[3] && counts[4] && counts[5] && counts[6]) {
        return true;
    }
    return false;
}

bool Yahtzee(int dice[]) {
    int counts[7] = {0};
    for (int i = 0; i < NUM_DICE; i++) {
        counts[dice[i]]++;
    }
    for (int i = 1; i <= 6; i++) {
        if (counts[i] == 5) {
            return true;
        }
    }
    return false;
}

int sumOfDice(int dice[]) {
    int sum = 0;
    for (int i = 0; i < NUM_DICE; i++) {
        sum += dice[i];
    }
    return sum;
}

// Function to find the best category for the computer
int bestCategory(int dice[], int categoriesUsed[]) {
    int bestScore = -1;
    int bestCategory = -1;

    for (int category = 1; category <= NUM_CATEGORIES; category++) {
        if (!isCategoryUsed(category, categoriesUsed)) {
            int score = calculateScore(dice, category);
            if (score > bestScore) {
                bestScore = score;
                bestCategory = category;
            }
        }
    }
    // Mark the chosen category as used
    if (bestCategory != -1) {
        categoriesUsed[bestCategory - 1] = 1;  // Mark as used
    }
    return bestCategory;
}

// Function to choose category for human player
int chooseCategory(int categoriesUsed[]) {
    int category;
    printf("1-ones \n2-twos \n3-threes \n4-fours \n5-fives \n6-sixes \n7-Three of a kind \n8-four of a kind \n9-full house \n10-small straight \n11-large straight \n12-chance \n13-YAHTZEE\n");

    while (1) {
        printf("\nChoose a category (1-13): ");
        scanf("%d", &category);
        
        if (category < 1 || category > 13) {
            printf("Invalid category. Please choose a number between 1 and 13.\n");
        } else if (isCategoryUsed(category, categoriesUsed)) {
            printf("Category already used. Please choose another category.\n");
        } else {
            categoriesUsed[category - 1] = 1;  // Mark the category as used
            return category;  // Return the chosen category
        }
    }
}








